import { useState } from "react";

export default function ConversorDistancia() {
  const [metros, setMetros] = useState("");
  const [pes, setPes] = useState("");
  const [polegadas, setPolegadas] = useState("");

  const handleMetroChange = (e) => {
    const m = parseFloat(e.target.value);
    setMetros(e.target.value);
    setPes((m * 3.28084).toFixed(2));
    setPolegadas((m * 39.3701).toFixed(2));
  };

  const handlePesChange = (e) => {
    const p = parseFloat(e.target.value);
    setPes(e.target.value);
    const m = p / 3.28084;
    setMetros(m.toFixed(2));
    setPolegadas((m * 39.3701).toFixed(2));
  };

  const handlePolegadaChange = (e) => {
    const pol = parseFloat(e.target.value);
    setPolegadas(e.target.value);
    const m = pol / 39.3701;
    setMetros(m.toFixed(2));
    setPes((m * 3.28084).toFixed(2));
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Conversor de Distância</h1>
      <div className="space-y-4">
        <input type="number" placeholder="Metros" value={metros} onChange={handleMetroChange} className="border p-2 w-full" />
        <input type="number" placeholder="Pés" value={pes} onChange={handlePesChange} className="border p-2 w-full" />
        <input type="number" placeholder="Polegadas" value={polegadas} onChange={handlePolegadaChange} className="border p-2 w-full" />
      </div>
    </div>
  );
}