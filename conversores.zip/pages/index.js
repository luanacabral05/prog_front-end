import Link from 'next/link'

export default function Home() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Conversores</h1>
      <p className="mb-6">Este app contém conversores úteis: moeda, temperatura e medidas.</p>
      <ul className="space-y-2">
        <li><Link href="/sobre" className="text-blue-500 underline">Sobre</Link></li>
        <li><Link href="/conversor-moeda" className="text-blue-500 underline">Conversor de Moeda</Link></li>
        <li><Link href="/conversor-temperatura" className="text-blue-500 underline">Conversor de Temperatura</Link></li>
        <li><Link href="/conversor-distancia" className="text-blue-500 underline">Conversor de Distância</Link></li>
      </ul>
    </div>
  );
}