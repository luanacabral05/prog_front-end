import { useState } from "react";

export default function ConversorMoeda() {
  const cotacao = 5.2;
  const [real, setReal] = useState("");
  const [dolar, setDolar] = useState("");

  const handleRealChange = (e) => {
    const valor = e.target.value;
    setReal(valor);
    setDolar((parseFloat(valor) / cotacao).toFixed(2));
  };

  const handleDolarChange = (e) => {
    const valor = e.target.value;
    setDolar(valor);
    setReal((parseFloat(valor) * cotacao).toFixed(2));
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Conversor de Moeda</h1>
      <p className="mb-4">Cotação fixa: 1 USD = R$ 5,20</p>
      <div className="space-y-4">
        <input type="number" placeholder="Real (BRL)" value={real} onChange={handleRealChange} className="border p-2 w-full" />
        <input type="number" placeholder="Dólar (USD)" value={dolar} onChange={handleDolarChange} className="border p-2 w-full" />
      </div>
    </div>
  );
}