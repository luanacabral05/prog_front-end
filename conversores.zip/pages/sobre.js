export default function Sobre() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Sobre</h1>
      <p>Olá! Meu nome é [SEU NOME AQUI] e sou estudante de desenvolvimento web. Este app foi criado como exercício prático usando Next.js e TailwindCSS.</p>
    </div>
  )
}