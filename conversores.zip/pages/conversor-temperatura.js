import { useState } from "react";

export default function ConversorTemperatura() {
  const [celsius, setCelsius] = useState("");
  const [fahrenheit, setFahrenheit] = useState("");

  const handleCelsiusChange = (e) => {
    const valor = e.target.value;
    setCelsius(valor);
    setFahrenheit(((parseFloat(valor) * 9) / 5 + 32).toFixed(2));
  };

  const handleFahrenheitChange = (e) => {
    const valor = e.target.value;
    setFahrenheit(valor);
    setCelsius((((parseFloat(valor) - 32) * 5) / 9).toFixed(2));
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Conversor de Temperatura</h1>
      <div className="space-y-4">
        <input type="number" placeholder="Celsius (ºC)" value={celsius} onChange={handleCelsiusChange} className="border p-2 w-full" />
        <input type="number" placeholder="Fahrenheit (ºF)" value={fahrenheit} onChange={handleFahrenheitChange} className="border p-2 w-full" />
      </div>
    </div>
  );
}